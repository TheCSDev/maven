package com.thecsdev.commons.util.properties;

import com.thecsdev.commons.util.annotations.Virtual;

/**
 * An {@link ObjectProperty} whose {@code T} type is {@link Float}.
 */
public @Virtual class FloatProperty extends DefaultableProperty<Float>
{
	// ==================================================
	public FloatProperty() { super(0f, 0f); }
	public FloatProperty(Float value) { super((value != null) ? value : 0, 0f); }
	// ==================================================
	/**
	 * Same as {@link #get()}, but returns a {@code float} instead of a {@link Float}.
	 */
	public final Float getF() { return this.get(); }
	// ==================================================
}