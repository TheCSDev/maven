package com.thecsdev.commons.util.properties;

import com.thecsdev.commons.util.annotations.Virtual;

/**
 * An {@link ObjectProperty} whose {@code T} type is {@link Byte}.
 */
public @Virtual class ByteProperty extends DefaultableProperty<Byte>
{
	// ==================================================
	public ByteProperty() { super((byte)0, (byte)0); }
	public ByteProperty(Byte value) { super((value != null) ? value : 0, (byte)0); }
	// ==================================================
	/**
	 * Same as {@link #get()}, but returns a {@code byte} instead of a {@link Byte}.
	 */
	public final byte getB() { return this.get(); }
	// ==================================================
}