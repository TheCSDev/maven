package com.thecsdev.commons.util.properties;

import com.thecsdev.commons.util.annotations.Virtual;

/**
 * An {@link ObjectProperty} whose {@code T} type is {@link Boolean}.
 */
public @Virtual class BooleanProperty extends DefaultableProperty<Boolean>
{
	// ==================================================
	public BooleanProperty() { super(false, false); }
	public BooleanProperty(Boolean value) { super((value != null) ? value : false, false); }
	// ==================================================
	/**
	 * Same as {@link #get()}, but returns a {@code boolean} instead of a {@link Boolean}.
	 */
	public final Boolean getZ() { return this.get(); }
	// ==================================================
}