package com.thecsdev.commons.util.properties;

/**
 * A change listener is notified when the value of an {@link ObjectProperty} changes.
 */
@FunctionalInterface
public interface IChangeListener<T>
{
	/**
	 * Called when the value of a given {@link ObjectProperty} changes.
	 * @param property The {@link ObjectProperty} that was affected.
	 * @param oldValue The old value of the {@link ObjectProperty}.
	 * @param newValue The new value of the {@link ObjectProperty}.
	 * @apiNote Do NOT update the value the {@link ObjectProperty} from within
	 * an {@link IChangeListener}. Doing so will result in a {@link StackOverflowError}.
	 */
	public void onChanged(ObjectProperty<? extends T> property, T oldValue, T newValue);
}