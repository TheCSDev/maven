package com.thecsdev.commons.util.properties;

import com.thecsdev.commons.util.annotations.Virtual;

/**
 * An {@link ObjectProperty} whose {@code T} type is {@link Integer}.
 */
public @Virtual class IntegerProperty extends DefaultableProperty<Integer>
{
	// ==================================================
	public IntegerProperty() { super(0, 0); }
	public IntegerProperty(Integer value) { super((value != null) ? value : 0, 0); }
	// ==================================================
	/**
	 * Same as {@link #get()}, but returns an {@code int} instead of an {@link Integer}.
	 */
	public final int getI() { return this.get(); }
	// ==================================================
}