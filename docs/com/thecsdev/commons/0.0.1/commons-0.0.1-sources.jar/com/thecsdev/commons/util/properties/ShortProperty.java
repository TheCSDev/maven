package com.thecsdev.commons.util.properties;

import com.thecsdev.commons.util.annotations.Virtual;

/**
 * An {@link ObjectProperty} whose {@code T} type is {@link Short}.
 */
public @Virtual class ShortProperty extends DefaultableProperty<Short>
{
	// ==================================================
	public ShortProperty() { super((short)0, (short)0); }
	public ShortProperty(Short value) { super((value != null) ? value : 0, (short)0); }
	// ==================================================
	/**
	 * Same as {@link #get()}, but returns a {@code short} instead of a {@link Short}.
	 */
	public final Short getS() { return this.get(); }
	// ==================================================
}