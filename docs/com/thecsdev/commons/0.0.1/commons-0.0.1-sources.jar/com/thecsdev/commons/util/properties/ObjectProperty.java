package com.thecsdev.commons.util.properties;

import java.util.ArrayList;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Function;

import org.jetbrains.annotations.ApiStatus.Internal;
import org.jetbrains.annotations.Nullable;

import com.thecsdev.commons.util.TUtils;
import com.thecsdev.commons.util.annotations.CallerSensitive;
import com.thecsdev.commons.util.annotations.Virtual;

/**
 * A property wrapper for an {@link Object} of type {@code T}, similar to {@link AtomicReference}, 
 * but with additional utility features such as {@link IChangeListener}s.
 * 
 * @param <T> The type of the stored value.
 */
public @Virtual class ObjectProperty<T>
{
	// ==================================================
	private static final StackWalker SW_RCR = TUtils.getStackWalkerRCR();
	// --------------------------------------------------
	/**
	 * <b>Set flags:</b> Invoke change listeners.<br>
	 * Makes {@link #set(Object, int)} invoke {@link IChangeListener}s.
	 */
	public static final int SF_INVOKE_CHANGE_LISTENERS = 0b1;
	
	/**
	 * <b>Set flags:</b> All.<br>
	 * Applies all possible flags to {@link #set(Object, int)}.
	 */
	public static final int SF_ALL                     = 0b1;
	
	/**
	 * <b>Set flags:</b> Default.<br>
	 * Makes {@link #set(Object, int)} use the default flags.
	 */
	public static final int SF_DEFAULT                 = SF_ALL;
	// ==================================================
	private volatile @Nullable Class<?> owner    = null;
	private volatile           T        value    = null;
	private volatile           boolean  readOnly = false;
	// --------------------------------------------------
	// note: starts off null for memory performance reasons. no need to create
	//       an instance of it if it will never be used.
	private volatile @Nullable ArrayList<IChangeListener<T>> changeListeners;
	private volatile @Nullable Function<T, T>                preprocessor;
	private volatile @Nullable IChangeListener<T>            interceptor;
	// ==================================================
	public ObjectProperty() { this(null); }
	public ObjectProperty(T initialValue)
	{
		//first step; figure out who created and owns this object instance
		final AtomicReference<Class<?>> soughtOwner = new AtomicReference<>(null);
		SW_RCR.forEach(frame ->
		{
			if(soughtOwner.get() != null) return; //unfortunately can't optimize cuz Java being Java
			final var fdc = frame.getDeclaringClass();
			if(!ObjectProperty.class.isAssignableFrom(fdc))
				soughtOwner.set(fdc);
		});
		this.owner = soughtOwner.get();
		
		//second step; assign value
		//DEV. NOTE: Do NOT preprocess(...) here! That'd be a DANGEROUS call! (instance not yet initialized)
		this.value = initialValue;
	}
	// ==================================================
	/**
	 * Returns the {@link Class} that's responsible for the creation of this
	 * {@link ObjectProperty} instance.<br>
	 * The owner {@link Class} has special permissions that allow it to tweak
	 * certain behaviors of this {@link ObjectProperty}.
	 */
	public final Class<?> getOwner() { return this.owner; }
	
	/**
	 * Transfers ownership of this {@link ObjectProperty} to another {@link Class}
	 * by setting the value of {@link #getOwner()}.
	 * @param owner The new owner {@link Class}.
	 * @throws IllegalStateException If the calling {@link Class} is not allowed to call this method.
	 * @throws NullPointerException If an argument is {@code null}.
	 */
	@CallerSensitive
	public final void setOwner(Class<?> owner) throws IllegalStateException, NullPointerException
	{
		if(SW_RCR.getCallerClass() != this.owner)
			throwIllegalCallerException();
		this.owner = Objects.requireNonNull(owner);
	}
	// --------------------------------------------------
	/**
	 * Returns {@code true} if this {@link ObjectProperty} is "read only".
	 * Read-only {@link ObjectProperty}s prohibit {@link #set(Object, int)} calls.
	 */
	public final boolean isReadOnly() { return this.readOnly; }
	
	/**
	 * When set as "read only" is set to {@code true}, all {@link #set(Object, int)}
	 * calls throw an {@link IllegalStateException}.
	 * @param readOnly Whether or not this {@link ObjectProperty} should be "read only".
	 * @throws IllegalStateException If the calling {@link Class} is not allowed to call this method.
	 * @see #getOwner()
	 */
	@CallerSensitive
	public final void setReadOnly(boolean readOnly) throws IllegalStateException
	{
		if(SW_RCR.getCallerClass() != this.owner)
			throwIllegalCallerException();
		this.readOnly = readOnly;
	}
	// --------------------------------------------------
	/**
	 * Sets the "preprocessor" {@link Function} for this {@link ObjectProperty}.
	 * The preprocessor works similarly to {@link #preprocess(Object)}, by intercepting
	 * {@link #set(Object, int)} calls and tweaking the input value before it's set.
	 * @param preprocessor The preprocessor {@link Function} to set.
	 * @throws IllegalStateException If the calling {@link Class} is not allowed to call this method.
	 * @see #getOwner()
	 */
	@CallerSensitive
	public final void setPreprocessor(@Nullable Function<T, T> preprocessor) throws IllegalStateException
	{
		if(SW_RCR.getCallerClass() != this.owner)
			throwIllegalCallerException();
		this.preprocessor = preprocessor;
	}
	
	/**
	 * Assigns an {@link IChangeListener} as an interceptor for this {@link ObjectProperty}.  
	 * The interceptor will be invoked whenever a non-owner attempts to modify this property's value.<br>  
	 * If an interceptor is set, it will always receive and handle change attempts made by non-owners,  
	 * effectively preventing direct modifications.<br>
	 * Only the owner always bypasses the interceptor.<br>
	 * @param interceptor The interceptor that will handle non-owner modification attempts.
	 * @throws IllegalStateException If the calling {@link Class} is not allowed to call this method.
	 * @see #getOwner()
	 * @apiNote The interceptor will not intercept if {@link #isReadOnly()} returns {@code true}.
	 */
	@CallerSensitive
	public final void setInterceptor(@Nullable IChangeListener<T> interceptor) throws IllegalStateException
	{
		if(SW_RCR.getCallerClass() != this.owner)
			throwIllegalCallerException();
		this.interceptor = interceptor;
	}
	// --------------------------------------------------
	/**
	 * Throws a generic {@link IllegalStateException} indicating that a method was
	 * called by a {@link Class} that is not the {@link #getOwner()} of this
	 * {@link ObjectProperty}.
	 * @throws IllegalStateException Always.
	 */
	private static final @Internal void throwIllegalCallerException() throws IllegalStateException
	{
		throw new IllegalStateException("Invocation rejected: Unauthorized Class attempted to access this method",
				new IllegalAccessException("Access denied: The caller Class does not own this property"));
	}
	// ==================================================
	/**
	 * Returns the current value of this {@link ObjectProperty}.
	 */
	public final @Nullable T get() { return this.value; }
	
	/**
	 * Sets the current value of this {@link ObjectProperty}.<br>
	 * Uses the {@link #SF_DEFAULT} flags when calling {@link #set(Object, int)}.
	 * @param value The value to set.
	 * @throws IllegalStateException If {@link #isReadOnly()} returns {@code true}.
	 * @apiNote {@link #getOwner()} is allowed to bypass {@link #isReadOnly()} and
	 * call this method anyway.
	 */
	@CallerSensitive
	public final void set(@Nullable T value) throws IllegalStateException
	{
		__setInternal(value, SF_DEFAULT, SW_RCR.getCallerClass());
	}
	
	/**
	 * Sets the current value of this {@link ObjectProperty}, while also allowing you
	 * to define additional flags for the behavior of this function.
	 * @param value The value to set.
	 * @param flags The additional flags.
	 * @throws IllegalStateException If {@link #isReadOnly()} returns {@code true}.
	 * @see #SF_DEFAULT
	 * @apiNote {@link #getOwner()} is allowed to bypass {@link #isReadOnly()} and
	 * call this method anyway.
	 */
	@CallerSensitive
	public final void set(@Nullable T value, int flags) throws IllegalStateException
	{
		__setInternal(value, flags, SW_RCR.getCallerClass());
	}
	
	private final @Internal void __setInternal(@Nullable T value, int flags, Class<?> caller)
	{
		//prepare
		final boolean callerNotOwner = (caller != this.owner);
		
		//obtain old and new values, and then perform an equality check.
		//return if both end up being equal, as there's no need to proceed in that case
		value = preprocess(value);
		final @Nullable var preprocessor = this.preprocessor;
		if(preprocessor != null) value = preprocessor.apply(value);
		
		final var oldVal = this.value;
		if(oldVal == value || (oldVal != null && oldVal.equals(value))) //inlined Objects.equals
			return;
		
		//assign the new value
		final @Nullable var interceptor = callerNotOwner ? this.interceptor : null; //cannot intercept owner calls
		if(callerNotOwner) //intercept
		{
			if(this.readOnly) throw new IllegalStateException("Attempt to call set(...) on a read-only object property");
			else if(interceptor != null) { interceptor.onChanged(this, oldVal, value); return; }
		}
		this.value = value;
		
		//invoke change listeners if necessary
		final @Nullable var changeListeners = this.changeListeners;
		if(changeListeners != null && (flags & SF_INVOKE_CHANGE_LISTENERS) == SF_INVOKE_CHANGE_LISTENERS)
			for(final var changeListener : changeListeners)
				changeListener.onChanged(this, oldVal, value);
	}
	// --------------------------------------------------
	/**
	 * Called by {@link #set(Object)} prior to setting this {@link ObjectProperty}'s
	 * current value. Useful for things like sanitization, normalization, and ensuring
	 * the value always follows a specific format/ruleset.
	 * @param value The value to pre-process.
	 */
	protected @Virtual @Nullable T preprocess(T value) { return value; }
	// ==================================================
	/**
	 * Adds an {@link IChangeListener} to this {@link ObjectProperty}.
	 * @param changeListener The {@link IChangeListener} to add.
	 * @return The added {@link IChangeListener}.
	 * @throws NullPointerException If an argument is {@code null}.
	 */
	public final IChangeListener<T> addChangeListener(IChangeListener<T> changeListener) throws NullPointerException
	{
		//assert that the arguments aren't null
		Objects.requireNonNull(changeListener);
		
		//define the list if needed, add listener if not present
		if(this.changeListeners == null)
			this.changeListeners = new ArrayList<>();
		if(!this.changeListeners.contains(changeListener))
			this.changeListeners.add(changeListener);
		
		//return the added listener
		return changeListener;
	}
	
	/**
	 * Removes an {@link IChangeListener} from this {@link ObjectProperty}.
	 * @param changeListener The {@link IChangeListener} to remove.
	 * @return {@code true} if the {@link IChangeListener} was present prior to being removed.
	 */
	public final boolean removeChangeListener(IChangeListener<T> changeListener)
	{
		//cannot remove listeners if there are none
		if(this.changeListeners == null)
			return false;
		
		//remove the listener if it's present
		final var hadListener = this.changeListeners.contains(changeListener);
		if(hadListener)
			this.changeListeners.remove(changeListener);
		
		//for performance reasons, erase the list if no longer in use
		if(this.changeListeners.size() < 1)
			this.changeListeners = null;
		
		//return the return value
		return hadListener;
	}
	// ==================================================
	/**
	 * Returns an {@link Optional} containing the value of this {@link ObjectProperty}.
	 */
	public final Optional<T> asOptional() { return Optional.ofNullable(this.value); }
	// ==================================================
}