package com.thecsdev.commons.util.properties;

import com.thecsdev.commons.util.annotations.Virtual;

/**
 * An {@link ObjectProperty} whose {@code T} type is {@link Long}.
 */
public @Virtual class LongProperty extends DefaultableProperty<Long>
{
	// ==================================================
	public LongProperty() { super(0l, 0l); }
	public LongProperty(Long value) { super((value != null) ? value : 0, 0l); }
	// ==================================================
	/**
	 * Same as {@link #get()}, but returns a {@code long} instead of a {@link Long}.
	 */
	public final Long getJ() { return this.get(); }
	// ==================================================
}