package com.thecsdev.commons.util.properties;

import org.jetbrains.annotations.Nullable;

import com.thecsdev.commons.util.annotations.Virtual;

/**
 * An {@link ObjectProperty} whose value is set to the {@link #getDefaultValue()}
 * when attempting to set the value to {@code null}.
 */
public @Virtual class DefaultableProperty<T> extends ObjectProperty<T>
{
	// ==================================================
	private final @Nullable T defaultValue;
	// ==================================================
	public DefaultableProperty(@Nullable T defaultValue) { this(defaultValue, defaultValue); }
	public DefaultableProperty(@Nullable T value, @Nullable T defaultValue)
	{
		super((value != null) ? value : defaultValue);
		this.defaultValue = defaultValue;
	}
	// ==================================================
	protected @Virtual @Nullable @Override T preprocess(@Nullable T value) { return (value != null) ? value : this.defaultValue; }
	// ==================================================
	/**
	 * Returns the default value that is assigned when attempting to
	 * set the value to {@code null}.
	 */
	public final @Nullable T getDefaultValue() { return this.defaultValue; }
	// ==================================================
}