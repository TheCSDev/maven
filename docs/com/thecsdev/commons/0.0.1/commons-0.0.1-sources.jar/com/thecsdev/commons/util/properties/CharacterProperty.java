package com.thecsdev.commons.util.properties;

import com.thecsdev.commons.util.annotations.Virtual;

/**
 * An {@link ObjectProperty} whose {@code T} type is {@link Character}.
 */
public @Virtual class CharacterProperty extends DefaultableProperty<Character>
{
	// ==================================================
	public CharacterProperty() { super('\u0000', '\u0000'); }
	public CharacterProperty(Character value) { super((value != null) ? value : 0, '\u0000'); }
	// ==================================================
	/**
	 * Same as {@link #get()}, but returns a {@code char} instead of a {@link Character}.
	 */
	public final Character getC() { return this.get(); }
	// ==================================================
}