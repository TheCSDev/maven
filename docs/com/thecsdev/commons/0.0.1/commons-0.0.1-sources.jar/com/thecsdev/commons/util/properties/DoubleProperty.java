package com.thecsdev.commons.util.properties;

import com.thecsdev.commons.util.annotations.Virtual;

/**
 * An {@link ObjectProperty} whose {@code T} type is {@link Double}.
 */
public @Virtual class DoubleProperty extends DefaultableProperty<Double>
{
	// ==================================================
	public DoubleProperty() { super(0d, 0d); }
	public DoubleProperty(Double value) { super((value != null) ? value : 0, 0d); }
	// ==================================================
	/**
	 * Same as {@link #get()}, but returns a {@code double} instead of a {@link Double}.
	 */
	public final Double getD() { return this.get(); }
	// ==================================================
}