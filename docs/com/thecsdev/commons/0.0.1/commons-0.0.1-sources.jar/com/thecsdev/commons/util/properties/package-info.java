/**
 * Provides a set of property wrapper classes for primitive types and objects, 
 * extending the functionality of {@link com.thecsdev.commons.util.properties.ObjectProperty}.
 * These property wrappers allow observing value changes through
 * {@link com.thecsdev.commons.util.properties.IChangeListener}s.
 */
package com.thecsdev.commons.util.properties;