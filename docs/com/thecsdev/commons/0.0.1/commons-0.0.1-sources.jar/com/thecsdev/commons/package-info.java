/**
 * A collection of reusable utility classes and functions commonly
 * used across TheCSDev's Java projects.
 */
package com.thecsdev.commons;